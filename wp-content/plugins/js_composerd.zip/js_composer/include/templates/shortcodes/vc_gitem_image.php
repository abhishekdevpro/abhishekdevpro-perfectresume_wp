{{ featured_image:<?php echo http_build_query( $atts ) ?> }}
